package com.example.TruckSchedulingPodOne.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.TruckSchedulingPodOne.model.DC;

public interface DcDao  extends CrudRepository<DC, Integer>{

}
