package com.example.TruckSchedulingPodOne.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "dc_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DC {
	@Id
	@GeneratedValue
	private int id;
	private int dc_number;
	private String dc_city;
	private String dc_type;
	public DC() {
			}
	public DC(int id, int dc_number, String dc_city, String dc_type) {
		super();
		this.id = id;
		this.dc_number = dc_number;
		this.dc_city = dc_city;
		this.dc_type = dc_type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDc_number() {
		return dc_number;
	}
	public void setDc_number(int dc_number) {
		this.dc_number = dc_number;
	}
	public String getDc_city() {
		return dc_city;
	}
	public void setDc_city(String dc_city) {
		this.dc_city = dc_city;
	}
	public String getDc_type() {
		return dc_type;
	}
	public void setDc_type(String dc_type) {
		this.dc_type = dc_type;
	}
}
