package com.example.TruckSchedulingPodOne.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TruckSchedulingPodOne.dao.DcDao;
import com.example.TruckSchedulingPodOne.model.DC;

@RestController
@RequestMapping("/dc")
public class DcController {
	@Autowired
	private DcDao dao;

	@PostMapping("/addDc")
	public String addDC(@RequestBody DC dc) {
		System.out.println("Inputs : " + dc);
		dao.save(dc);
		return "DC is added";
	}

	@PostMapping("/addDcs")
	public String addDCs(@RequestBody List<DC> dcs) {
		System.out.println("Inputs : " + dcs);
		dao.saveAll(dcs);
		return "DC size is : " + dcs.size();
	}

	@GetMapping("/getDcs")
	public List<DC> getDcs() {
		return (List<DC>) dao.findAll();
	}

	@DeleteMapping("/deleteDc/{id}")
	public String deleteDc(@PathVariable int id) {
		dao.deleteById(id);
		return "DC removed !!" + id;
	}

	@PutMapping("/updateDc")
	public DC updateDc(@RequestBody DC dc) {
		DC existingDC = dao.findById(dc.getId()).orElse(null);
		existingDC.setDc_number(dc.getDc_number());
		existingDC.setDc_city(dc.getDc_city());
		existingDC.setDc_type(dc.getDc_type());
		return dao.save(existingDC);
	}

}
