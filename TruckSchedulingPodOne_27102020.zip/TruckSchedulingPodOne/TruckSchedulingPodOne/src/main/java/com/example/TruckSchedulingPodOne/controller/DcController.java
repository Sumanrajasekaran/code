package com.example.TruckSchedulingPodOne.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TruckSchedulingPodOne.model.DC;
import com.example.TruckSchedulingPodOne.service.DcService;

@RestController
@RequestMapping("/dc")
public class DcController {
	
	@Autowired
	private DcService dcservice;

	@PostMapping("/addDc")
	public String addDC(@RequestBody DC dc) {
	return dcservice.saveDC(dc);
	}

	@PostMapping("/addDcs")
	public String addDCs(@RequestBody List<DC> dcs) {
	return dcservice.saveDcList(dcs);
	}

	@GetMapping("/getDcs")
	public List<DC> getDcs() {
		return dcservice.getDcList();
		}

	@DeleteMapping("/deleteDc/{dc_number}")
	public String deleteDc(@PathVariable int dc_number) {
		return dcservice.deleteDcById(dc_number);
	}

	@PutMapping("/updateDc")
	public DC updateDc(@RequestBody DC dc) {
		return dcservice.updateDcValue(dc);
	}

}
