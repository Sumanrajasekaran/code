package com.example.TruckSchedulingPodOne;

import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

 

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.web.client.TestRestTemplate;

import org.springframework.boot.web.server.LocalServerPort;

import org.springframework.http.HttpEntity;

import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpMethod;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.test.context.junit4.SpringRunner;

import org.springframework.web.client.HttpClientErrorException;

 

import com.example.TruckSchedulingPodOne.model.Appointment;

 

 

 

 

@RunWith(SpringRunner.class)

@SpringBootTest(classes = TruckSchedulingPodOneApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

 

public class AppointmentApplicationTest {

      

      

       @Autowired

    private TestRestTemplate restTemplate;

 

    @LocalServerPort

    private int port;

 

    private String getRootUrl() {

        return "http://localhost:" + port;

    }

 

    @Test

    public void contextLoads() {

 

    }

 

    @Test

    public void testGeAppointments() {

    HttpHeaders headers = new HttpHeaders();

       HttpEntity<String> entity = new HttpEntity<String>(null, headers);

       ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/appointments",

       HttpMethod.GET, entity, String.class); 

       assertNotNull(response.getBody());

   }

 

   @Test

   public void testGetAppointmentById() {

          Appointment appointment = restTemplate.getForObject(getRootUrl() + "/appointments/24", Appointment.class);

       System.out.println(appointment.getId());

       assertNotNull(appointment);

   }

 

   @Test

   public void testAddAppointment() {

          Appointment appointment = new Appointment();

          appointment.setDcNumber(12345678);


       ResponseEntity<Appointment> postResponse = restTemplate.postForEntity(getRootUrl() + "/appointments", appointment, Appointment.class);

       assertNotNull(postResponse);

       assertNotNull(postResponse.getBody());

   }

 

   @Test

   public void testUpdateAppointment() {

       int id = 17;

       Appointment appointment = restTemplate.getForObject(getRootUrl() + "/appointments/" + id, Appointment.class);

       appointment.setQuantity(9);

       restTemplate.put(getRootUrl() + "/appointments/" + id, appointment);

       Appointment updatedappointmentslots = restTemplate.getForObject(getRootUrl() + "/appointments/" + id, Appointment.class);

       assertNotNull(updatedappointmentslots);

   }

 

   @Test

   public void testDeleteAppointmentSlots() {

        int id = 17;

        Appointment appointment = restTemplate.getForObject(getRootUrl() + "/appointments/" + id, Appointment.class);

        assertNotNull(appointment);

        restTemplate.delete(getRootUrl() + "/appointments/" + id);

        try {

             appointment = restTemplate.getForObject(getRootUrl() + "/appointments/" + id, Appointment.class);

        } catch (final HttpClientErrorException e) {

             assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);

        }

   }

 

}
