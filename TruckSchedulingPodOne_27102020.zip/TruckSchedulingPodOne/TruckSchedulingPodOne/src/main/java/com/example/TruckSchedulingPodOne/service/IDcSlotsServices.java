package com.example.TruckSchedulingPodOne.service;

import java.util.List;

import com.example.TruckSchedulingPodOne.model.DcSlots;





public interface IDcSlotsServices {
	
	List<DcSlots> getDCSlots();
	
	DcSlots addDCSlots(DcSlots dcSlots);
	DcSlots updateDCSlots(int dcNumber ,DcSlots dcSlots);
	DcSlots getDCSlot(int dcNumber);
	boolean deleteDCSlots(int dcNumber);
	
	
}
