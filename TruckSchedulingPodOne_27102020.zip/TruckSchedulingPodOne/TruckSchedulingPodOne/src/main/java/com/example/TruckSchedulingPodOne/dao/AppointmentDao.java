package com.example.TruckSchedulingPodOne.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.TruckSchedulingPodOne.model.Appointment;

public interface AppointmentDao extends CrudRepository<Appointment, Integer>{

	
	public Optional<Appointment> findByPoNumber(Double poNumber);
}
