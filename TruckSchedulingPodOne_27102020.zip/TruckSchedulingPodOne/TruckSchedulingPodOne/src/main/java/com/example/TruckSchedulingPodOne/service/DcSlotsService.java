package com.example.TruckSchedulingPodOne.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TruckSchedulingPodOne.dao.IDcSlotsDAO;
import com.example.TruckSchedulingPodOne.model.DcSlots;

@Service
public class DcSlotsService implements IDcSlotsServices {
	
	@Autowired
	private IDcSlotsDAO dcsdao;

	@Override
	public List<DcSlots> getDCSlots() {
		return dcsdao.getDCSlots();
	}

	@Override
	public DcSlots addDCSlots(DcSlots dcSlots) {
		SimpleDateFormat df = new SimpleDateFormat("HH:mm");
		 
		try {
			Date d = df.parse(dcSlots.getStartTime());
			Calendar cal = Calendar.getInstance();
			 cal.setTime(d);
			 cal.add(Calendar.MINUTE, 60);
			dcSlots.setEndTime(df.format(cal.getTime()));
			dcSlots.setTimeSlot(dcSlots.getStartTime()+"-"+dcSlots.getEndTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		 

		
		return dcsdao.addDCSlots(dcSlots);
	}

	@Override
	public DcSlots updateDCSlots(int dcNumber, DcSlots dcSlots) {
		return dcsdao.updateDCSlots(dcNumber, dcSlots);
	}

	@Override
	public DcSlots getDCSlot(int dcNumber) {
		return dcsdao.getDCSlot(dcNumber);
	}

	@Override
	public boolean deleteDCSlots(int dcNumber) {
		return dcsdao.deleteDCSlots(dcNumber);
	}

}