package com.example.TruckSchedulingPodOne.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "dc_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DC implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private int dc_number;
	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name = "dc_type")
	@JsonIgnoreProperties(value = {"dc_master", "hibernateLazyInitializer"})
	private DcType dcTypeBean;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable=false)
	private Date createdOn;
	private String createdBy;
	private String dc_city;
	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedOn;
	private String updatedBy;


	public int getDc_number() {
		return dc_number;
	}

	public void setDc_number(int dc_number) {
		this.dc_number = dc_number;
	}

	public String getDc_city() {
		return dc_city;
	}

	public void setDc_city(String dc_city) {
		this.dc_city = dc_city;
	}

	public Date getcreatedOn() {
		return createdOn;
	}

	public void setcreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public DcType getDcTypeBean() {
		return dcTypeBean;
	}

	public void setDcTypeBean(DcType dcTypeBean) {
		this.dcTypeBean = dcTypeBean;
	}

	public DC() {
	}
}
