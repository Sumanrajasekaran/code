package com.example.TruckSchedulingPodOne.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.TruckSchedulingPodOne.dao.DcDao;
import com.example.TruckSchedulingPodOne.model.DC;

@Component
public class DcService{

	@Autowired
	private DcDao dao;
		
	public String saveDC(DC dc) {
		System.out.println("Inputs : " + dc);
		dao.save(dc);
		return "DC is added";
	}

	public String saveDcList(List<DC> dcs) {
		System.out.println("Inputs : " + dcs);
		dao.saveAll(dcs);
		return "DC size is : " + dcs.size();
	}

	public List<DC> getDcList() {
		return (List<DC>) dao.findAll();
	}

		public String deleteDcById(int dc_number) {
		dao.deleteById(dc_number);
		return "DC removed !!" + dc_number;
	}

		public DC updateDcValue(DC dc) {
		DC existingDC = dao.findById(dc.getDc_number()).orElse(null);
		existingDC.setDc_city(dc.getDc_city());
		existingDC.setDcTypeBean(dc.getDcTypeBean());
		existingDC.setUpdatedBy(dc.getUpdatedBy());
		return dao.save(existingDC);
	}
		

}
