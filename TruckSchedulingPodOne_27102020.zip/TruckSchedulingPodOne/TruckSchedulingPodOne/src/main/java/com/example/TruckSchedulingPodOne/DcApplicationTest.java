package com.example.TruckSchedulingPodOne;

import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

 

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.web.client.TestRestTemplate;

import org.springframework.boot.web.server.LocalServerPort;

import org.springframework.http.HttpEntity;

import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpMethod;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.test.context.junit4.SpringRunner;

import org.springframework.web.client.HttpClientErrorException;

 

import com.example.TruckSchedulingPodOne.model.DC;

 

 

 

 

@RunWith(SpringRunner.class)

@SpringBootTest(classes = TruckSchedulingPodOneApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

 

public class DcApplicationTest {

      

      

       @Autowired

    private TestRestTemplate restTemplate;

 

    @LocalServerPort

    private int port;

 

    private String getRootUrl() {

        return "http://localhost:" + port;

    }

 

    @Test

    public void contextLoads() {

 

    }

 

    @Test

    public void testGeDCs() {

    HttpHeaders headers = new HttpHeaders();

       HttpEntity<String> entity = new HttpEntity<String>(null, headers);

       ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/dcs",

       HttpMethod.GET, entity, String.class); 

       assertNotNull(response.getBody());

   }

 

   @Test

   public void testGetDCById() {

          DC dc = restTemplate.getForObject(getRootUrl() + "/dcs/24", DC.class);

       System.out.println(dc.getDc_number());

       assertNotNull(dc);

   }

 

   @Test

   public void testAddDC() {

          DC dc = new DC();

          dc.setDc_number(9000);


       ResponseEntity<DC> postResponse = restTemplate.postForEntity(getRootUrl() + "/dcs", dc, DC.class);

       assertNotNull(postResponse);

       assertNotNull(postResponse.getBody());

   }

 

   @Test

   public void testUpdateDC() {

       int id = 17;

       DC dc = restTemplate.getForObject(getRootUrl() + "/dcs/" + id, DC.class);

       dc.setDc_city("Chennai");

       restTemplate.put(getRootUrl() + "/dcs/" + id, dc);

       DC updateddcslots = restTemplate.getForObject(getRootUrl() + "/dcs/" + id, DC.class);

       assertNotNull(updateddcslots);

   }

 

   @Test

   public void testDeleteDCSlots() {

        int id = 17;

        DC dc = restTemplate.getForObject(getRootUrl() + "/dcs/" + id, DC.class);

        assertNotNull(dc);

        restTemplate.delete(getRootUrl() + "/dcs/" + id);

        try {

             dc = restTemplate.getForObject(getRootUrl() + "/dcs/" + id, DC.class);

        } catch (final HttpClientErrorException e) {

             assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);

        }

   }

 

}
