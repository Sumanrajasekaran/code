package com.example.TruckSchedulingPodOne.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TruckSchedulingPodOne.model.Vendor;
import com.example.TruckSchedulingPodOne.service.VendorService;


@RestController
@RequestMapping("/vendor")
public class VendorController {

	@Autowired
	private VendorService vendorService;

	@PostMapping("/addVendor")
	public String addVendor(@RequestBody Vendor vendor) {
	return vendorService.saveVendor(vendor);
	}

	@PostMapping("/addVendorList")
	public String addVendorList(@RequestBody List<Vendor> vendorList) {
	return vendorService.saveVendorList(vendorList);
	}

	@GetMapping("/getVendorList")
	public List<Vendor> getVendorList() {
		return vendorService.getVendorList();
		}

	@DeleteMapping("/deleteVendor/{id}")
	public String deleteVendor(@PathVariable int id) {
		return vendorService.deleteVendorById(id);
	}

	@PutMapping("/updateVendor")
	public Vendor updateVendor(@RequestBody Vendor vendor) {
		return vendorService.updateVendor(vendor);
	}

}