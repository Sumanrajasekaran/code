package com.example.TruckSchedulingPodOne.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.ReadOnlyProperty;



@Entity
@Table
public class DcType implements Serializable{
	
	private static final long serialVersionUID=1L;
	
	@Id
	@Column(updatable=false)
	@ReadOnlyProperty
	private int id;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(updatable=false)
	private Date createdOn;
	@Column(updatable=false)
	@ReadOnlyProperty
	private String typeDesc;
	
//	@OneToMany(mappedBy="dcTypeBean")
//	private List<DC> dcs;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public DcType() {
		
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getTypeDesc() {
		return typeDesc;
	}
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}
	

//	public List<DC> getDcs() {
//		return dcs;
//	}
//	public void setDcs(List<DC> dcs) {
//		this.dcs = dcs;
//	}
	
//	public DC addDc(DC dc) {
//		getDcs().add(dc);
//		dc.setDcTypeBean(this);
//		return dc;
//	}
//	public DC removeDc(DC dc) {
//		getDcs().remove(dc);
//		dc.setDcTypeBean(this);
//		return dc;
//	}
}
