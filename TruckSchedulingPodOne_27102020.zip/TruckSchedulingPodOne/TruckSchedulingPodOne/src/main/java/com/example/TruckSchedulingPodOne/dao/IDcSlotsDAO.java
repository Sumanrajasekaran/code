package com.example.TruckSchedulingPodOne.dao;

import java.util.List;
import java.util.Optional;

import com.example.TruckSchedulingPodOne.model.DcSlots;


public interface IDcSlotsDAO {
	
	List<DcSlots> getDCSlots();
	
	DcSlots addDCSlots(DcSlots dcSlots);
	DcSlots updateDCSlots(int dcNumber ,DcSlots dcSlots);
	DcSlots getDCSlot(int dcNumber);
	boolean deleteDCSlots(int dcNumber);
	public boolean findByMaxCount(int maxCount,int dcNumber);

}