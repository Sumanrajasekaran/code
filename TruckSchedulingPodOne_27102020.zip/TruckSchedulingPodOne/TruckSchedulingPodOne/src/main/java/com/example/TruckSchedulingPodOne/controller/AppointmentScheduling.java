package com.example.TruckSchedulingPodOne.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TruckSchedulingPodOne.model.Appointment;
import com.example.TruckSchedulingPodOne.service.AppointmentService;
import com.example.TruckSchedulingPodOne.service.ResponseMessage;

@RestController
@RequestMapping("/appointment")
public class AppointmentScheduling {
	
	@Autowired
	private AppointmentService appointmentService;

	@PostMapping("/addAppointment")
	public ResponseEntity<ResponseMessage> addAppointment(@Validated @RequestBody Appointment appointment) {
		ResponseMessage responseMessage=new ResponseMessage();
		responseMessage=appointmentService.saveAppointment(appointment);
		return ResponseEntity.ok(responseMessage);
	}

//	@PostMapping("/addAppointmentList")
//	public String addAppointmentList(@RequestBody List<Appointment> appointmentList) {
//	return appointmentService.saveAppointmentList(appointmentList);
//	}

	@GetMapping("/getAppointmentList")
	public List<Appointment> getAppointmentList() {
		return appointmentService.getAppointmentList();
		}

	@DeleteMapping("/deleteAppointment/{id}")
	public String deleteAppointment(@PathVariable int id) {
		return appointmentService.deleteAppointmentById(id);
	}

	@PutMapping("/updateAppointment")
	public Appointment updateAppointment(@RequestBody Appointment appointment) {
		return appointmentService.updateAppointment(appointment);
	}

}