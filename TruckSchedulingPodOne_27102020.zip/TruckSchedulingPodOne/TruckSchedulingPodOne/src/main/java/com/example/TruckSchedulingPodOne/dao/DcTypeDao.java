package com.example.TruckSchedulingPodOne.dao;


import org.springframework.data.repository.CrudRepository;

import com.example.TruckSchedulingPodOne.model.DcType;

public interface DcTypeDao extends CrudRepository<DcType, Integer>{

}
