package com.example.TruckSchedulingPodOne.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.TruckSchedulingPodOne.dao.AppointmentDao;
import com.example.TruckSchedulingPodOne.dao.IDcSlotsDAO;
import com.example.TruckSchedulingPodOne.model.Appointment;
import com.example.TruckSchedulingPodOne.model.DcSlots;

@Component
public class AppointmentService {

	@Autowired
	private AppointmentDao appointmentDao;
	
	@Autowired
	private IDcSlotsDAO dcsDao;

	public ResponseMessage saveAppointment(Appointment appointment){
		System.out.println("Inputs : " + appointment);
		ResponseMessage responseMessage=new ResponseMessage();
		Optional<Appointment> poResult= appointmentDao.findByPoNumber(appointment.getPoNumber());
		boolean dcResult= dcsDao.findByMaxCount(appointment.getQuantity(), appointment.getDcNumber());
		if(dcResult) {
			if(!(poResult.isPresent())) {
			Appointment appointmentResult=appointmentDao.save(appointment);
			if(appointmentResult == null || appointmentResult.equals(null))
			{
			responseMessage.setPoMessage("Failure");
		}else {
			responseMessage.setPoMessage("Success");
		}
	}else {
		responseMessage.setPoMessage("Po Number already exists");
	}
		}else {
			responseMessage.setPoMessage("Trucks maximum count reached");
		}
	return responseMessage;
}

	public String saveAppointmentList(List<Appointment> appointments) {
		System.out.println("Inputs : " + appointments);
		appointmentDao.saveAll(appointments);
		return "Appointment size is : " + appointments.size();
	}

	public List<Appointment> getAppointmentList() {
		return (List<Appointment>) appointmentDao.findAll();
	}

	public String deleteAppointmentById(int id) {
		appointmentDao.deleteById(id);
		return "Appointment removed !!" + id;
	}

	public Appointment updateAppointment(Appointment appointment) {
		Appointment existingAppointment = appointmentDao.findById(appointment.getId()).orElse(null);
		existingAppointment.setTruckNumber(appointment.getTruckNumber());
		existingAppointment.setDcNumber(appointment.getDcNumber());
		existingAppointment.setDcSlot(appointment.getDcSlot());
		existingAppointment.setAppointmentDate(appointment.getAppointmentDate());
		existingAppointment.setQuantity(appointment.getQuantity());
		existingAppointment.setUpdatedBy(appointment.getUpdatedBy());
		return appointmentDao.save(existingAppointment);
	}

}
