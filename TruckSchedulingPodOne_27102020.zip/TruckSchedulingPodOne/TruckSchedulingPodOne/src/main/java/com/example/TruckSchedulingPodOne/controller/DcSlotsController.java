package com.example.TruckSchedulingPodOne.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TruckSchedulingPodOne.model.DcSlots;
import com.example.TruckSchedulingPodOne.service.IDcSlotsServices;


@RestController
@RequestMapping("/dc_slots_service")
//@Qualifier("IDcSlotsServices")

public class DcSlotsController {
	
	@Autowired
	private IDcSlotsServices dcsservice;
	
	
	
	@GetMapping("/dcSlots")
	public ResponseEntity<List<DcSlots>> getDcSlots() {
		
		List<DcSlots> dcslots = dcsservice.getDCSlots();
		return new ResponseEntity<List<DcSlots>>(dcslots,HttpStatus.OK);
	}
	
	@GetMapping("/dcSlots/{dcNumber}")
	public ResponseEntity<DcSlots> getDCSlot(@PathVariable("dcNumber") Integer dcNumber){
	DcSlots dc = dcsservice.getDCSlot(dcNumber);
	return new ResponseEntity<DcSlots>(dc,HttpStatus.OK);
	
	}
	
	@PostMapping("/dcSlots")
	public ResponseEntity<DcSlots> addDCSlots(@RequestBody DcSlots dc){
		DcSlots dcs = dcsservice.addDCSlots(dc);
		return new ResponseEntity<DcSlots>(dcs,HttpStatus.OK);
	}
	
	
	@PutMapping("/dcSlots/{dcNumber}")
	public ResponseEntity<DcSlots> updateDCSlots(@PathVariable("dcNumber") int dcNumber, @RequestBody DcSlots dc){
		DcSlots dcs = dcsservice.updateDCSlots(dcNumber, dc);
		return new ResponseEntity<DcSlots>(dcs,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/dcSlots/{dcNumber}")
	public ResponseEntity<String> deleteDCSlots(@PathVariable("dcNumber") int dcNumber){
		boolean isDeleted = dcsservice.deleteDCSlots(dcNumber);
		if(isDeleted){
			String responseContent = "DC_Slots details has been deleted success	fully";
			return new ResponseEntity<String>(responseContent,HttpStatus.OK);
		}
		String error = "Error while deleting DC_Slots details from database";
		return new ResponseEntity<String>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}