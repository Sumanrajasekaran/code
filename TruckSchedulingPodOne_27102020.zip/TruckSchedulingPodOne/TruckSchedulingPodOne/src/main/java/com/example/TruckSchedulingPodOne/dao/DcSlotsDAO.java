package com.example.TruckSchedulingPodOne.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.TruckSchedulingPodOne.model.Appointment;
import com.example.TruckSchedulingPodOne.model.DcSlots;


@Transactional
@Repository
public class DcSlotsDAO  implements IDcSlotsDAO{
	
	
	@PersistenceContext
	private EntityManager entityManagerDcSlots;

	@SuppressWarnings("unchecked")
	@Override
	public List<DcSlots> getDCSlots() {
		
		
		String hql = "FROM DcSlots as dcs ORDER BY dcs.dcNumber";
		return (List<DcSlots>) entityManagerDcSlots.createQuery(hql).getResultList();
		
	}
	
	@Override
	public DcSlots addDCSlots(DcSlots dcSlots) {
		entityManagerDcSlots.persist(dcSlots);
		DcSlots ds = getLastInsertedDcSlots();
		return ds;
	}

	private DcSlots getLastInsertedDcSlots() {
		String hql = "from DcSlots order by dcNumber DESC";
		Query query = entityManagerDcSlots.createQuery(hql);
		query.setMaxResults(1);
		DcSlots dc = (DcSlots)query.getSingleResult();
		return dc;
	}

	@Override
	public DcSlots updateDCSlots(int dcNumber, DcSlots dcSlots) {
		
		DcSlots dcDB = getDCSlot(dcNumber);
		dcDB.setTimeSlot(dcSlots.getTimeSlot());
		dcDB.setMaxTrucks(dcSlots.getMaxTrucks());
		
		entityManagerDcSlots.flush();
		
		DcSlots updatedDc = getDCSlot(dcNumber);
		return updatedDc;
		
	}

	@Override
	public DcSlots getDCSlot(int dcNumber) {
		return entityManagerDcSlots.find(DcSlots.class, dcNumber);
	}

	@Override
	public boolean deleteDCSlots(int dcNumber) {
		DcSlots dc = getDCSlot(dcNumber);
		entityManagerDcSlots.remove(dc);
		boolean status = entityManagerDcSlots.contains(dc);
		if(status){
			return false;
		}
		return true;
	
	}
	
	@Override
	public boolean findByMaxCount(int maxCount,int dcNumber) {
		String hql = "select dcNumber from DcSlots where dc_number= :dc_number and max_trucks => :max_trucks";
		List selectedRow = entityManagerDcSlots.createQuery(hql).setParameter("dc_number", dcNumber).setParameter("max_trucks", maxCount).getResultList();
//		query.setParameter("dc_number", getDCSlot(dcNumber));
//		query.setParameter("max_trucks", getDCSlot(maxCount));
//		int selectedRow=query.executeUpdate();
		if(selectedRow.isEmpty()){
			return false;
		}else {
		return true;
		}
	}

	
}
