package com.example.TruckSchedulingPodOne.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.TruckSchedulingPodOne.model.Vendor;

public interface VendorDao extends CrudRepository<Vendor, Integer>{

}
