package com.example.TruckSchedulingPodOne.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.TruckSchedulingPodOne.dao.VendorDao;
import com.example.TruckSchedulingPodOne.model.Vendor;


@Component
public class VendorService {

	@Autowired
	private VendorDao vendorDao;
		
	public String saveVendor(Vendor vendor) {
		System.out.println("Inputs : " + vendor);
		vendorDao.save(vendor);
		return "Vendor is added";
	}

	public String saveVendorList(List<Vendor> vendors) {
		System.out.println("Inputs : " + vendors);
		vendorDao.saveAll(vendors);
		return "Vendor size is : " + vendors.size();
	}

	public List<Vendor> getVendorList() {
		return (List<Vendor>) vendorDao.findAll();
	}

		public String deleteVendorById(int id) {
		vendorDao.deleteById(id);
		return "Vendor removed !!" + id;
	}

		public Vendor updateVendor(Vendor vendor) {
		Vendor existingVendor = vendorDao.findById(vendor.getId()).orElse(null);
		existingVendor.setVendorName(vendor.getVendorName());
		existingVendor.setVendorEmail(vendor.getVendorEmail());
		existingVendor.setVendorPhone(vendor.getVendorPhone());
		existingVendor.setVendorAddress(vendor.getVendorAddress());
		existingVendor.setUpdatedBy(vendor.getUpdatedBy());
		return vendorDao.save(existingVendor);
	}
		

}

