package com.example.TruckSchedulingPodOne.service;

public class ResponseMessage {
	
	private String poMessage;
	private int maxCount;

	public String getPoMessage() {
		return poMessage;
	}

	public void setPoMessage(String poMessage) {
		this.poMessage = poMessage;
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

	public ResponseMessage() {
		super();
	}	

}
