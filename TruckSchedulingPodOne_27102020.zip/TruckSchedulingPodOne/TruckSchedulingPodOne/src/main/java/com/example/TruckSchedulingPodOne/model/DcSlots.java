package com.example.TruckSchedulingPodOne.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "DC_Slots")

public class DcSlots {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "dc_number")
	private int dcNumber;

	@Transient
	private transient String startTime;

	@Transient
	private transient String endTime;
	
	@Column(name = "dc_timeSlots")
	private String timeSlot;

	// private LocalDate dcTimeSlots;
	// startime
	// endtime +1
	// object
	// @Column(name = "CREATED_DATE")
	// LocalDate date;

	@Column(name = "max_trucks")
	private String maxTrucks;

	public int getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(int dcNumber) {
		this.dcNumber = dcNumber;
	}
	

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public 	String getMaxTrucks() {
		return maxTrucks;
	}

	public void setMaxTrucks(String maxTrucks) {
		this.maxTrucks = maxTrucks;
	}

}