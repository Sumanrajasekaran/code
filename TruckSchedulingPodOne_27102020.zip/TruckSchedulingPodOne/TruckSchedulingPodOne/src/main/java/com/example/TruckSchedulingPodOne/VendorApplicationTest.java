package com.example.TruckSchedulingPodOne;

import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

 

import org.junit.Test;

import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.web.client.TestRestTemplate;

import org.springframework.boot.web.server.LocalServerPort;

import org.springframework.http.HttpEntity;

import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpMethod;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.test.context.junit4.SpringRunner;

import org.springframework.web.client.HttpClientErrorException;

 

import com.example.TruckSchedulingPodOne.model.Vendor;

 

 

 

 

@RunWith(SpringRunner.class)

@SpringBootTest(classes = TruckSchedulingPodOneApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)

 

public class VendorApplicationTest {

      

      

       @Autowired

    private TestRestTemplate restTemplate;

 

    @LocalServerPort

    private int port;

 

    private String getRootUrl() {

        return "http://localhost:" + port;

    }

 

    @Test

    public void contextLoads() {

 

    }

 

    @Test

    public void testGeVendors() {

    HttpHeaders headers = new HttpHeaders();

       HttpEntity<String> entity = new HttpEntity<String>(null, headers);

       ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/vendors",

       HttpMethod.GET, entity, String.class); 

       assertNotNull(response.getBody());

   }

 

   @Test

   public void testGetVendorById() {

          Vendor vendor = restTemplate.getForObject(getRootUrl() + "/vendors/52", Vendor.class);

       System.out.println(vendor.getId());

       assertNotNull(vendor);

   }

 

   @Test

   public void testAddVendor() {

          Vendor vendor = new Vendor();

          vendor.setVendorName("Vendor 1");


       ResponseEntity<Vendor> postResponse = restTemplate.postForEntity(getRootUrl() + "/vendors", vendor, Vendor.class);

       assertNotNull(postResponse);

       assertNotNull(postResponse.getBody());

   }

 

   @Test

   public void testUpdateVendor() {

       int id = 17;

       Vendor vendor = restTemplate.getForObject(getRootUrl() + "/vendors/" + id, Vendor.class);

       vendor.setVendorAddress("Chennai");

       restTemplate.put(getRootUrl() + "/vendors/" + id, vendor);

       Vendor updatedvendorslots = restTemplate.getForObject(getRootUrl() + "/vendors/" + id, Vendor.class);

       assertNotNull(updatedvendorslots);

   }

 

   @Test

   public void testDeleteVendorSlots() {

        int id = 17;

        Vendor vendor = restTemplate.getForObject(getRootUrl() + "/vendors/" + id, Vendor.class);

        assertNotNull(vendor);

        restTemplate.delete(getRootUrl() + "/vendors/" + id);

        try {

             vendor = restTemplate.getForObject(getRootUrl() + "/vendors/" + id, Vendor.class);

        } catch (final HttpClientErrorException e) {

             assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);

        }

   }

 

}
