package com.example.TruckSchedulingPodOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruckSchedulingPodOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
